﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using CapaEntidad;
using System.Text;
using static CapaEntidad.E_GCllientes;



namespace CapaLogica
{
    public class D_GClientes
    {
        SqlConnection conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["conectar"].ConnectionString);

        //n---------------------------------------------------- Tabla Clietes--------------------------------------------- //

        public List<Factura> ListarFacturas(object Conectar)
        {
            List<Factura> lista = new List<Factura>();
            SqlCommand cmd = new SqlCommand("sp_ListarFacturas", conexion);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;

            conexion.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                lista.Add(new Factura
                {
                    IdFactura = reader.GetInt32(0),
                    IdCliente = reader.GetInt32(1),
                    Fecha = reader.GetDateTime(2),
                    Total = reader.GetDecimal(3),
                    Estado = reader.GetBoolean(4)
                });
            }
            conexion.Close();
            return lista;
        }

        // ------------------------------------------ Tabla Detalle de Factura ----------------------------------------------//

        public class DetalleFacturaDatos
        {
            SqlConnection conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["conectar"].ConnectionString);
            public void Insertar(DetalleFactura detalle)
            {
                SqlCommand cmd = new SqlCommand("sp_InsertarDetalleFactura", conexion);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@IdFactura", detalle.IdFactura);
                cmd.Parameters.AddWithValue("@Descripcion", detalle.Descripcion);
                cmd.Parameters.AddWithValue("@Cantidad", detalle.Cantidad);
                cmd.Parameters.AddWithValue("@Precio", detalle.Precio);

                conexion.Open();
                cmd.ExecuteNonQuery();
                conexion.Close();
            }

            public void Actualizar(DetalleFactura detalle)
            {;
                SqlCommand cmd = new SqlCommand("sp_ActualizarDetalleFactura", conexion);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@IdDetalle", detalle.IdDetalle);
                cmd.Parameters.AddWithValue("@IdFactura", detalle.IdFactura);
                cmd.Parameters.AddWithValue("@Descripcion", detalle.Descripcion);
                cmd.Parameters.AddWithValue("@Cantidad", detalle.Cantidad);
                cmd.Parameters.AddWithValue("@Precio", detalle.Precio);

                conexion.Open();
                cmd.ExecuteNonQuery();
                conexion.Close();
            }

            public void Eliminar(int idDetalle)
            {
                SqlCommand cmd = new SqlCommand("sp_EliminarDetalleFactura", conexion);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@IdDetalle", idDetalle);

                conexion.Open();
                cmd.ExecuteNonQuery();
                conexion.Close();
            }

            public List<DetalleFactura> Listar()
            {
                List<DetalleFactura> lista = new List<DetalleFactura>();
                SqlCommand cmd = new SqlCommand("sp_ListarDetalleFactura", conexion);
                cmd.CommandType = CommandType.StoredProcedure;

                conexion.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    lista.Add(new DetalleFactura
                    {
                        IdDetalle = reader.GetInt32(0),
                        IdFactura = reader.GetInt32(1),
                        Descripcion = reader.GetString(2),
                        Cantidad = reader.GetInt32(3),
                        Precio = reader.GetDecimal(4)
                    });
                }
                conexion.Close();
                return lista;
            }
        }

        // -------------------------------------Tabla Clientes---------------------------------------------------------- //
        public class ClienteDatos
        {
            SqlConnection conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["conectar"].ConnectionString);
            public void Insertar(Cliente cliente)
            {
                SqlCommand cmd = new SqlCommand("sp_InsertarCliente", conexion);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@Nombre", cliente.Nombre);
                cmd.Parameters.AddWithValue("@Correo", cliente.Correo);
                cmd.Parameters.AddWithValue("@Telefono", cliente.Telefono);
                cmd.Parameters.AddWithValue("@Estado", cliente.Estado);

                conexion.Open();
                cmd.ExecuteNonQuery();
                conexion.Close();
            }
        }

    }
}
