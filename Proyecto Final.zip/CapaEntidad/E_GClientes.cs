﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaEntidad
{
    public class E_GCllientes
    {
        public class Cliente
        {
            public int IdCliente { get; set; }
            public string Nombre { get; set; }
            public string Correo { get; set; }
            public string Telefono { get; set; }
            public bool Estado { get; set; }
        }

        public class Factura
        {
            public int IdFactura { get; set; }
            public int IdCliente { get; set; }
            public DateTime Fecha { get; set; }
            public decimal Total { get; set; }
            public bool Estado { get; set; }
        }

        public class DetalleFactura
        {
            public int IdDetalle { get; set; }
            public int IdFactura { get; set; }
            public string Descripcion { get; set; }
            public int Cantidad { get; set; }
            public decimal Precio { get; set; }
        }
    }

}
