﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using CapaEntidad;
using CapaLogica;
using System.Data;
using static CapaEntidad.E_GCllientes;

namespace CapaNegocios
{
    public class N_GClientes
    {
        // ----------------------------- Cliente ----------------------------- //

        D_GClientes.ClienteDatos objCliente = new D_GClientes.ClienteDatos();

        public void InsertandoCliente(Cliente cliente)
        {
            objCliente.Insertar(cliente);
        }

        // ----------------------------- Factura ----------------------------- //

        D_GClientes objFactura = new D_GClientes();

        public List<Factura> ListarFacturas()
        {
            return objFactura.ListarFacturas(null); // Parámetro no usado
        }

        // ------------------------ Detalle Factura -------------------------- //

        D_GClientes.DetalleFacturaDatos objDetalle = new D_GClientes.DetalleFacturaDatos();

        public List<DetalleFactura> ListarDetalles()
        {
            return objDetalle.Listar();
        }

        public void InsertandoDetalle(DetalleFactura detalle)
        {
            objDetalle.Insertar(detalle);
        }

        public void EditandoDetalle(DetalleFactura detalle)
        {
            objDetalle.Actualizar(detalle);
        }

        public void EliminandoDetalle(int idDetalle)
        {
            objDetalle.Eliminar(idDetalle);
        }
    }
    
}
