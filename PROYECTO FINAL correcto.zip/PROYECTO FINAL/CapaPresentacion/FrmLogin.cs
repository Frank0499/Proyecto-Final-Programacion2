﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaPresentacion
{
    public partial class FrmLogin : Form
    {
        public FrmLogin()
        {
            InitializeComponent();
        }

        private void FrmLogin_Load(object sender, EventArgs e)
        {

        }
        private void btnLogin_Click(object sender, EventArgs e)
        {
            string usuario = txtUsuario.Text.Trim();
            string clave = txtClave.Text.Trim();

            if (usuario == "admin" && clave == "1234")
            {
                MessageBox.Show("¡Bienvenido al sistema!", "Acceso correcto", MessageBoxButtons.OK, MessageBoxIcon.Information);
                // Aquí podrías abrir el formulario principal y ocultar este
                this.Hide();
                Form formularioPrincipal = new FrmLogin(); // Reemplaza con el nombre de tu formulario principal
                formularioPrincipal.Show();
            }
            else
            {
                MessageBox.Show("Usuario o contraseña incorrectos.", "Error de acceso", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
