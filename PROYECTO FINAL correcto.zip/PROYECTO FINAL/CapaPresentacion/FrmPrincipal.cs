﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaPresentacion
{
    public partial class FrmPrincipal : Form
    {
        public FrmPrincipal()
        {
            InitializeComponent();
        }

        private void btnClientes_Click(object sender, EventArgs e)
        {
            FrmClientes frm = new FrmClientes();
            frm.ShowDialog();
        }

        private void btnFacturas_Click(object sender, EventArgs e)
        {
            FrmFacturas frm = new FrmFacturas();
            frm.ShowDialog();
        }

        private void btnDetalleFactura_Click(object sender, EventArgs e)
        {
            FrmDetalleFactura frm = new FrmDetalleFactura();
            frm.ShowDialog();
        }
    }
}
