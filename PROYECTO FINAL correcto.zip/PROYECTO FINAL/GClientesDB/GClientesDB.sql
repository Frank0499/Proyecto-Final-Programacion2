Create database GClientesDB

USE GClientesDB

-- Tabla Clientes
CREATE TABLE Clientes (
    IdCliente INT PRIMARY KEY IDENTITY(1,1),
    Nombre NVARCHAR(100) NOT NULL,
    Correo NVARCHAR(100),
    Tel�fono NVARCHAR(20),
    Estado BIT NOT NULL -- 1 = Activo, 0 = Inactivo
);

-- Tabla Facturas
CREATE TABLE Facturas (
    IdFactura INT PRIMARY KEY IDENTITY(1,1),
    IdCliente INT NOT NULL,
    Fecha DATETIME NOT NULL,
    Total DECIMAL(18, 2) NOT NULL,
    Estado BIT NOT NULL, -- 1 = Activa, 0 = Cancelada
    CONSTRAINT FK_Facturas_Clientes FOREIGN KEY (IdCliente) REFERENCES Clientes(IdCliente)
);

-- Tabla DetalleFactura
CREATE TABLE DetalleFactura (
    IdDetalle INT PRIMARY KEY IDENTITY(1,1),
    IdFactura INT NOT NULL,
    Descripci�n NVARCHAR(200) NOT NULL,
    Cantidad INT NOT NULL,
    Precio DECIMAL(18, 2) NOT NULL,
    Subtotal AS (Cantidad * Precio) PERSISTED,
    CONSTRAINT FK_DetalleFactura_Facturas FOREIGN KEY (IdFactura) REFERENCES Facturas(IdFactura)
);
go
--- Procesos Almacenados.

--Tabla Clientes
-- Insertar Cliente
CREATE PROCEDURE sp_InsertarCliente
    @Nombre NVARCHAR(100),
    @Correo NVARCHAR(100),
    @Telefono NVARCHAR(20),
    @Estado BIT
AS
BEGIN
    INSERT INTO Clientes (Nombre, Correo, Tel�fono, Estado)
    VALUES (@Nombre, @Correo, @Telefono, @Estado);
END;
GO
-- Actualizar Cliente
CREATE PROCEDURE sp_ActualizarCliente
    @IdCliente INT,
    @Nombre NVARCHAR(100),
    @Correo NVARCHAR(100),
    @Telefono NVARCHAR(20),
    @Estado BIT
AS
BEGIN
    UPDATE Clientes
    SET Nombre = @Nombre,
        Correo = @Correo,
        Tel�fono = @Telefono,
        Estado = @Estado
    WHERE IdCliente = @IdCliente;
END;
GO
-- Eliminar Cliente
CREATE PROCEDURE sp_EliminarCliente
    @IdCliente INT
AS
BEGIN
    DELETE FROM Clientes WHERE IdCliente = @IdCliente;
END;
GO
-- Listar Clientes
CREATE PROCEDURE sp_ListarClientes
AS
BEGIN
    SELECT * FROM Clientes;
END;
GO


 --- Tabla Factura ----

 -- Insertar Factura
CREATE PROCEDURE sp_InsertarFactura
    @IdCliente INT,
    @Fecha DATETIME,
    @Total DECIMAL(18,2),
    @Estado BIT
AS
BEGIN
    INSERT INTO Facturas (IdCliente, Fecha, Total, Estado)
    VALUES (@IdCliente, @Fecha, @Total, @Estado);
END;
GO
-- Actualizar Factura
CREATE PROCEDURE sp_ActualizarFactura
    @IdFactura INT,
    @IdCliente INT,
    @Fecha DATETIME,
    @Total DECIMAL(18,2),
    @Estado BIT
AS
BEGIN
    UPDATE Facturas
    SET IdCliente = @IdCliente,
        Fecha = @Fecha,
        Total = @Total,
        Estado = @Estado
    WHERE IdFactura = @IdFactura;
END;
GO
-- Eliminar Factura
CREATE PROCEDURE sp_EliminarFactura
    @IdFactura INT
AS
BEGIN
    DELETE FROM Facturas WHERE IdFactura = @IdFactura;
END;
GO
-- Listar Facturas
CREATE PROCEDURE sp_ListarFacturas
AS
BEGIN
    SELECT * FROM Facturas;
END;
GO

---Tabla Detalle de Factura ---
-- Insertar DetalleFactura
CREATE PROCEDURE sp_InsertarDetalleFactura
    @IdFactura INT,
    @Descripcion NVARCHAR(200),
    @Cantidad INT,
    @Precio DECIMAL(18,2)
AS
BEGIN
    INSERT INTO DetalleFactura (IdFactura, Descripci�n, Cantidad, Precio)
    VALUES (@IdFactura, @Descripcion, @Cantidad, @Precio);
END;
GO
-- Actualizar DetalleFactura
CREATE PROCEDURE sp_ActualizarDetalleFactura
    @IdDetalle INT,
    @IdFactura INT,
    @Descripcion NVARCHAR(200),
    @Cantidad INT,
    @Precio DECIMAL(18,2)
AS
BEGIN
    UPDATE DetalleFactura
    SET IdFactura = @IdFactura,
        Descripci�n = @Descripcion,
        Cantidad = @Cantidad,
        Precio = @Precio
    WHERE IdDetalle = @IdDetalle;
END;
GO
-- Eliminar DetalleFactura
CREATE PROCEDURE sp_EliminarDetalleFactura
    @IdDetalle INT
AS
BEGIN
    DELETE FROM DetalleFactura WHERE IdDetalle = @IdDetalle;
END;
GO
-- Listar DetallesFactura
CREATE PROCEDURE sp_ListarDetalleFactura
AS
BEGIN
    SELECT * FROM DetalleFactura;
END;
