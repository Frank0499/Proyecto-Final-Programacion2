﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using CapaEntidad;
using System.Text;
using static CapaEntidad.E_GClientes;



namespace CapaLogica
{
    public class D_GDetalleFactura
    {
        private readonly string connectionString = ConfigurationManager.ConnectionStrings["conectar"].ConnectionString;

        public void Insertar(DetalleFactura detalle)
        {
            using (SqlConnection conexion = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("sp_InsertarDetalleFactura", conexion))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@IdFactura", detalle.IdFactura);
                    cmd.Parameters.AddWithValue("@Descripcion", detalle.Descripcion);
                    cmd.Parameters.AddWithValue("@Cantidad", detalle.Cantidad);
                    cmd.Parameters.AddWithValue("@Precio", detalle.Precio);

                    conexion.Open();
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public void Actualizar(DetalleFactura detalle)
        {
            using (SqlConnection conexion = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("sp_ActualizarDetalleFactura", conexion))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@IdDetalle", detalle.IdDetalle);
                    cmd.Parameters.AddWithValue("@IdFactura", detalle.IdFactura);
                    cmd.Parameters.AddWithValue("@Descripcion", detalle.Descripcion);
                    cmd.Parameters.AddWithValue("@Cantidad", detalle.Cantidad);
                    cmd.Parameters.AddWithValue("@Precio", detalle.Precio);

                    conexion.Open();
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public void Eliminar(int idDetalle)
        {
            using (SqlConnection conexion = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("sp_EliminarDetalleFactura", conexion))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@IdDetalle", idDetalle);

                    conexion.Open();
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public List<DetalleFactura> Listar()
        {
            List<DetalleFactura> lista = new List<DetalleFactura>();

            using (SqlConnection conexion = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("sp_ListarDetalleFactura", conexion))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    conexion.Open();

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            lista.Add(new DetalleFactura
                            {
                                IdDetalle = reader.GetInt32(0),
                                IdFactura = reader.GetInt32(1),
                                Descripcion = reader.GetString(2),
                                Cantidad = reader.GetInt32(3),
                                Precio = reader.GetDecimal(4)
                            });
                        }
                    }
                }
            }

            return lista;
        }
    }
}
