﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using CapaEntidad;
using System.Text;
using static CapaEntidad.E_GClientes;




namespace CapaLogica
{
    public class D_GFacturas
    {
        private readonly string connectionString = ConfigurationManager.ConnectionStrings["conectar"].ConnectionString;

        public List<Factura> ListarFacturas()
        {
            List<Factura> lista = new List<Factura>();

            using (SqlConnection conexion = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("sp_ListarFacturas", conexion))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    conexion.Open();

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            lista.Add(new Factura
                            {
                                IdFactura = reader.GetInt32(0),
                                IdCliente = reader.GetInt32(1),
                                Fecha = reader.GetDateTime(2),
                                Total = reader.GetDecimal(3),
                                Estado = reader.GetBoolean(4)
                            });
                        }
                    }
                }
            }

            return lista;
        }
    }
}
