﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using CapaEntidad;
using System.Text;
using static CapaEntidad.E_GClientes;



namespace CapaLogica
{
    public class D_GClientes
    {
        public List<Factura> ListarFacturas(object value)
        {
            throw new NotImplementedException();
        }

        // -------------------------------------Tabla Clientes---------------------------------------------------------- //
        public class ClienteDatos
        {
            SqlConnection conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["conectar"].ConnectionString);
            public void Insertar(Cliente cliente)
            {
                SqlCommand cmd = new SqlCommand("sp_InsertarCliente", conexion);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@Nombre", cliente.Nombre);
                cmd.Parameters.AddWithValue("@Correo", cliente.Correo);
                cmd.Parameters.AddWithValue("@Telefono", cliente.Telefono);
                cmd.Parameters.AddWithValue("@Estado", cliente.Estado);

                conexion.Open();
                cmd.ExecuteNonQuery();
                conexion.Close();
            }
        }

    }
}
